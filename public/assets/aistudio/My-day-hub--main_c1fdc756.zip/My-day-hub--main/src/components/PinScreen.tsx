import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Delete, Check, ShieldCheck } from 'lucide-react';
import { Logo } from './Logo';
import { hashPin, verifyPin } from '../utils/crypto';
import { PinData, savePinData } from '../utils/storage';

interface PinScreenProps {
  mode: 'unlock' | 'create' | 'change';
  storedPinData?: PinData | null;
  onSuccess: () => void;
  onCancelChange?: () => void;
}

export const PinScreen: React.FC<PinScreenProps> = ({
  mode,
  storedPinData,
  onSuccess,
  onCancelChange,
}) => {
  const [pin, setPin] = useState<string>('');
  const [createStep, setCreateStep] = useState<'enter' | 'confirm'>('enter');
  const [firstPin, setFirstPin] = useState<string>('');
  const [oldPinVerified, setOldPinVerified] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isShaking, setIsShaking] = useState<boolean>(false);

  const triggerShake = (msg: string) => {
    setIsShaking(true);
    setErrorMsg(msg);
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([40, 60, 40]);
      } catch {
        // ignore vibrate restrictions
      }
    }
    setTimeout(() => {
      setIsShaking(false);
      setPin('');
    }, 600);
  };

  const handleKeyPress = (num: string) => {
    if (pin.length >= 6) return;
    setErrorMsg('');
    const nextPin = pin + num;
    setPin(nextPin);
  };

  const handleBackspace = () => {
    setErrorMsg('');
    setPin(prev => prev.slice(0, -1));
  };

  const handleClear = () => {
    setErrorMsg('');
    setPin('');
  };

  const handleConfirmAction = async (pinToTest: string = pin) => {
    if (pinToTest.length < 4) {
      triggerShake('PIN must be at least 4 digits');
      return;
    }

    if (mode === 'unlock') {
      if (!storedPinData) {
        onSuccess();
        return;
      }
      const isValid = await verifyPin(pinToTest, storedPinData.hash, storedPinData.salt);
      if (isValid) {
        onSuccess();
      } else {
        triggerShake('Incorrect PIN. Please try again.');
      }
      return;
    }

    if (mode === 'change' && !oldPinVerified) {
      if (!storedPinData) {
        setOldPinVerified(true);
        setPin('');
        return;
      }
      const isValid = await verifyPin(pinToTest, storedPinData.hash, storedPinData.salt);
      if (isValid) {
        setOldPinVerified(true);
        setPin('');
        setErrorMsg('');
      } else {
        triggerShake('Current PIN is incorrect');
      }
      return;
    }

    if (createStep === 'enter') {
      setFirstPin(pinToTest);
      setPin('');
      setCreateStep('confirm');
      setErrorMsg('');
    } else {
      if (pinToTest !== firstPin) {
        triggerShake('PINs did not match. Please restart setup.');
        setCreateStep('enter');
        setFirstPin('');
        return;
      }
      const hashed = await hashPin(pinToTest);
      savePinData(hashed);
      onSuccess();
    }
  };

  let title = 'Enter Your PIN';
  let subtitle = 'Enter your 4–6 digit PIN to unlock your personal journal';

  if (mode === 'create') {
    if (createStep === 'enter') {
      title = 'Create a Secure PIN';
      subtitle = 'Set a 4 to 6 digit PIN to protect your personal day hub';
    } else {
      title = 'Confirm Your PIN';
      subtitle = 'Re-enter your PIN to confirm';
    }
  } else if (mode === 'change') {
    if (!oldPinVerified) {
      title = 'Current PIN';
      subtitle = 'Enter your existing PIN to proceed with changes';
    } else if (createStep === 'enter') {
      title = 'New PIN';
      subtitle = 'Enter a new 4 to 6 digit PIN';
    } else {
      title = 'Confirm New PIN';
      subtitle = 'Re-enter your new PIN to confirm';
    }
  }

  const targetDots = Math.max(4, pin.length);

  return (
    <div className="fixed inset-0 z-40 flex flex-col items-center justify-between bg-[var(--color-paper)] text-[var(--color-ink)] p-6 select-none paper-grain">
      {/* Top Header & Branding */}
      <div className="w-full max-w-xs flex flex-col items-center pt-8 text-center">
        <div className="mb-5">
          <Logo size={48} />
        </div>
        <h2 className="font-serif text-3xl font-medium tracking-tight">
          {title}
        </h2>
        <p className="mt-1.5 text-xs text-[var(--color-muted)] font-sans leading-relaxed">
          {subtitle}
        </p>

        {/* PIN Dot Indicators - Animating scale and opacity (NO 'transparent' color interpolation warning) */}
        <motion.div
          animate={isShaking ? { x: [-10, 10, -6, 6, -3, 3, 0] } : { x: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center justify-center gap-4 my-7 py-2"
          role="status"
          aria-label={`${pin.length} digits entered`}
        >
          {Array.from({ length: targetDots }).map((_, index) => {
            const isFilled = index < pin.length;
            return (
              <div
                key={index}
                className="w-4 h-4 rounded-full border border-[var(--color-muted)] flex items-center justify-center p-0.5"
              >
                <motion.div
                  initial={false}
                  animate={{
                    scale: isFilled ? 1 : 0,
                    opacity: isFilled ? 1 : 0,
                  }}
                  transition={{ duration: 0.15 }}
                  className="w-full h-full rounded-full bg-[var(--color-marigold)]"
                />
              </div>
            );
          })}
        </motion.div>

        {/* Error message */}
        <div className="h-5 flex items-center justify-center">
          <AnimatePresence>
            {errorMsg && (
              <motion.span
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="text-xs font-medium text-[var(--color-oxblood)]"
              >
                {errorMsg}
              </motion.span>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Number Keypad */}
      <div className="w-full max-w-xs pb-6">
        <div className="grid grid-cols-3 gap-3 place-items-center">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(digit => (
            <button
              key={digit}
              onClick={() => handleKeyPress(digit)}
              className="w-16 h-16 rounded-lg border border-[var(--color-hairline)] bg-[var(--color-card)] font-mono text-2xl font-normal text-[var(--color-ink)] active:bg-[var(--color-paper)] active:border-[var(--color-marigold)] active:scale-95 transition-all flex items-center justify-center cursor-pointer"
              aria-label={`Digit ${digit}`}
            >
              {digit}
            </button>
          ))}

          {/* Clear Button */}
          <button
            onClick={handleClear}
            className="w-16 h-16 rounded-lg font-mono text-xs uppercase tracking-wider text-[var(--color-muted)] hover:text-[var(--color-ink)] active:scale-95 transition-all flex items-center justify-center cursor-pointer"
            aria-label="Clear PIN input"
          >
            Clear
          </button>

          {/* 0 Button */}
          <button
            onClick={() => handleKeyPress('0')}
            className="w-16 h-16 rounded-lg border border-[var(--color-hairline)] bg-[var(--color-card)] font-mono text-2xl font-normal text-[var(--color-ink)] active:bg-[var(--color-paper)] active:border-[var(--color-marigold)] active:scale-95 transition-all flex items-center justify-center cursor-pointer"
            aria-label="Digit 0"
          >
            0
          </button>

          {/* Backspace Button */}
          <button
            onClick={handleBackspace}
            className="w-16 h-16 rounded-lg text-[var(--color-muted)] hover:text-[var(--color-ink)] active:scale-95 transition-all flex items-center justify-center cursor-pointer"
            aria-label="Delete last digit"
          >
            <Delete className="w-5 h-5 stroke-[1.5]" />
          </button>
        </div>

        {/* Action Button */}
        <div className="mt-5 flex items-center justify-center gap-3">
          {mode === 'change' && onCancelChange && (
            <button
              onClick={onCancelChange}
              className="px-4 py-3 rounded-lg border border-[var(--color-hairline)] text-xs font-medium text-[var(--color-muted)] hover:text-[var(--color-ink)] transition cursor-pointer"
            >
              Cancel
            </button>
          )}

          <button
            onClick={() => handleConfirmAction()}
            disabled={pin.length < 4}
            className={`flex-1 py-3 px-6 rounded-lg font-medium text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer ${
              pin.length >= 4
                ? 'bg-[var(--color-marigold)] text-[var(--color-paper)] hover:opacity-90 active:scale-98'
                : 'bg-[var(--color-hairline)] text-[var(--color-muted)] cursor-not-allowed opacity-60'
            }`}
            aria-label="Submit PIN"
          >
            <Check className="w-4 h-4 stroke-[2]" />
            <span>
              {mode === 'unlock'
                ? 'Unlock Journal'
                : createStep === 'enter'
                ? 'Next'
                : 'Confirm & Save'}
            </span>
          </button>
        </div>

        {/* Offline Notice */}
        <div className="mt-5 flex items-center justify-center gap-1.5 text-xs text-[var(--color-muted)]">
          <ShieldCheck className="w-4 h-4 stroke-[1.5] text-[var(--color-marigold)]" />
          <span>Stored offline on device only.</span>
        </div>
      </div>
    </div>
  );
};
